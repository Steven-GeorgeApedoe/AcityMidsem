let submit = document.getElementById(submitButton);
submit.addEventListener("click", myfuction)
function myfunction(){
  alert('It has been clicked!')
}
